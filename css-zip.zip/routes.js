const express = require("express");
const router = express.Router();
const controller = require("./controllers/userController");

router.get("/", (req, res, next) => {
  const session = req.session;
  if (session.user != undefined) {
    res.redirect("/battle");
    return;
  }
  res.render("load");
});

router.get("/battle", (req, res, next) => {
  const { allotedImages, score, time } = req.session.user;
  console.log(time);
  res.render("index", {
    imageIndex: allotedImages[score.length],
    number: score.length,
    firstEntered: time[0],
  });
});

router.post("/login", controller.loginController);

router.post("/score", controller.scoreController);

module.exports = router;
