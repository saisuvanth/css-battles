# Demo
https://dear-terrific-nemophila.glitch.me/

# How to install

Run the following command:

```npm install && npm start```

THen it will display the port number at which the server is running.

# Installing on Glitch

You'll need to pass the "--no-sandbox" argument to puppeteer. This is done because Glitch projects run inside docker containers.
