const user = require("../models/User");

exports.loginController = (req, res, next) => {
  const { username, password } = req.body;
  user.findOne({ username }).then((result) => {
    if (result === null) {
      let i = 0;
      let array = [];
      while (i < 3) {
        const randomNumber = Math.floor(Math.random() * 8);
        let search = array.filter((a) => a === randomNumber);
        if (search.length === 0) {
          array.push(randomNumber);
          i++;
        }
      }
      const us = new user({
        username,
        password,
        allotedImages: array,
        time: [new Date()],
      });
      us.save().then((response) => {});
      let session = req.session;
      session.user = us;
    } else {
      if (result.password !== password) {
        res.send("Either this password is wrong or Username is already taken");
        return;
      }
      let session = req.session;
      session.user = result;
    }
    res.redirect("/battle");
  });
};

exports.scoreController = (req, res, next) => {
  const sc = req.body.score;
  console.log(req.body);
  const { _id } = req.session.user;
  user
    .findOneAndUpdate(
      { _id },
      { $push: { score: sc, time: new Date() } },
      { returnDocument: "after" }
    )
    .then((result) => {
      console.log(result);
      req.session.user = result;
      res.status(200).send("Done");
    });
};
